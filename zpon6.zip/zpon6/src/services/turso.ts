import bcrypt from 'bcryptjs';
import { AppSettings, Debtor, DebtorTransaction, Manager, User, InstallmentRecord, DatabaseAccount, Supplier, SupplierTransaction, SettledStorageStats, SubscriptionType, ManagerModuleAccess, AppLayoutTheme } from '../types';
import { generateShieldHeaders, signLocalSessionUser, verifyLocalSessionUser } from '../utils/securityShield';
import { ALDION_DATABASE_CONFIG, SECONDARY_DATABASE_CONFIG, THIRD_DATABASE_CONFIG, BACKUP_SYNC_DATABASES, BUILTIN_DEDICATED_DATABASES, normalizeTursoUrl } from '../aldion';
import { setSecuredPassword, getSecuredPassword } from '../utils/sanitize';

/**
 * Returns the backend API server base URL.
 * Supports:
 * 1. Custom URL set in settings / APK config (localStorage: aldion_backend_server_url)
 * 2. Current origin in web browser (window.location.origin)
 * 3. Default production Cloud Run backend host
 */
export function getBackendBaseUrl(): string {
  if (typeof window === 'undefined') return '';

  const saved = localStorage.getItem('aldion_backend_server_url');
  if (saved && saved.trim()) {
    return saved.trim().replace(/\/+$/, '');
  }

  // If running directly on Cloud Run backend, return current origin
  if (
    typeof window !== 'undefined' &&
    window.location &&
    window.location.origin &&
    window.location.origin.startsWith('http') &&
    window.location.origin.includes('run.app')
  ) {
    return window.location.origin;
  }

  // Default production Cloud Run backend host for Netlify / external static domains / mobile APKs
  return 'https://ais-pre-3qeeb6jl5bktm64omzuibv-349740974703.europe-west2.run.app';
}

export function setBackendBaseUrl(url: string) {
  if (url && url.trim()) {
    localStorage.setItem('aldion_backend_server_url', url.trim().replace(/\/+$/, ''));
  } else {
    localStorage.removeItem('aldion_backend_server_url');
  }
}

/**
 * محرك استعلام مدمج مشفر (Embedded Encrypted Engine)
 * يعمل تلقائياً عند تحويل المشروع إلى PWA أو تطبيق هاتف أو استضافة ثابتة،
 * بحيث يستخرج الرابط والتوكن المشفرين بالبايتات ويتصل بالقاعدة مباشرة دون الحاجة لأي خادم خارجي.
 */
export async function queryCustomTursoDirect(
  url: string,
  token: string,
  trimmedSql: string,
  args: (string | number | null | undefined)[] = []
) {
  if (!url || !token) {
    throw new Error('بيانات الاتصال بقاعدة البيانات غير مهيأة');
  }

  if (url.includes('app.turso.tech')) {
    throw new Error('رابط لوحة التحكم غير صالح كإندبوينت لقاعدة البيانات. يرجى استخدام رابط الاتصال المباشر بصيغة libsql://your-db-org.turso.io');
  }

  const normalizedUrl = normalizeTursoUrl(url);

  const formattedArgs = args.map((a) => {
    if (typeof a === 'number') {
      return Number.isInteger(a)
        ? { type: 'integer', value: String(a) }
        : { type: 'float', value: a };
    }
    if (a === null || a === undefined) {
      return { type: 'null' };
    }
    return { type: 'text', value: String(a) };
  });

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(normalizedUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          { type: 'execute', stmt: { sql: trimmedSql, args: formattedArgs } },
          { type: 'close' },
        ],
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      if (normalizedUrl.includes('app.turso.tech')) {
        throw new Error('رابط لوحة التحكم غير صالح كإندبوينت لقاعدة البيانات. يرجى التوجه إلى لوحة Turso ونسخ رابط القراءة والكتابة بصيغة libsql://your-db-org.turso.io');
      }
      throw new Error(`تعذر الاتصال برابط قاعدة البيانات (${res.status}): يرجى التأكد من استخدام رابط القاعدة الصحيح بصيغة libsql://...turso.io`);
    }

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`خطأ في قاعدة البيانات السحابية (${res.status}): ${errText.slice(0, 100) || res.statusText}`);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في استعلام قاعدة البيانات');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('انتهت مهلة الاتصال بقاعدة البيانات السحابية (Timeout)');
    }
    if (err.message === 'Failed to fetch' || err instanceof TypeError) {
      throw new Error('تعذر الاتصال بالقاعدة (Failed to fetch). يرجى التأكد من صحة رابط الاتصال المباشر المبتدئ بـ libsql:// وتوفر الإنترنت');
    }
    throw err;
  }
}

export function resolveDatabaseConfig(databaseId: string | null | undefined): { url: string; token: string; name: string } {
  if (databaseId === 'builtin_third_alidion2' || databaseId === 'alidion2' || databaseId === 'third') {
    return {
      url: THIRD_DATABASE_CONFIG.url,
      token: THIRD_DATABASE_CONFIG.token,
      name: 'القاعدة الثالثة المنفصلة (alidion2)',
    };
  }
  if (databaseId === 'builtin_secondary' || databaseId === 'secondary') {
    return {
      url: SECONDARY_DATABASE_CONFIG.url,
      token: SECONDARY_DATABASE_CONFIG.token,
      name: 'القاعدة الثانوية للمزامنة (AWS Mumbai)',
    };
  }
  if (databaseId && databaseId !== 'default') {
    const dbs = getLocalDatabases();
    const found = dbs.find((d) => d.id === databaseId);
    if (found && found.url && found.token) {
      return {
        url: found.url,
        token: found.token,
        name: found.name,
      };
    }
  }
  return {
    url: ALDION_DATABASE_CONFIG.url,
    token: ALDION_DATABASE_CONFIG.token,
    name: 'القاعدة الرئيسية (الافتراضية)',
  };
}

export async function queryTargetDatabase(
  databaseId: string | null | undefined,
  trimmedSql: string,
  args: (string | number | null | undefined)[] = []
) {
  if (!databaseId || databaseId === 'default') {
    return queryEmbeddedEncryptedTurso(trimmedSql, args);
  }
  const config = resolveDatabaseConfig(databaseId);
  return queryCustomTursoDirect(config.url, config.token, trimmedSql, args);
}

async function queryEmbeddedEncryptedTurso(trimmedSql: string, args: (string | number | null | undefined)[]) {
  const isWrite = /^(INSERT|UPDATE|DELETE|CREATE|DROP|ALTER)/i.test(trimmedSql);

  try {
    const res = await queryCustomTursoDirect(ALDION_DATABASE_CONFIG.url, ALDION_DATABASE_CONFIG.token, trimmedSql, args);
    // الكتابة المزدوجة المتزامنة المضمونة (Reliable Multi-Live Sync) في جميع القواعد الثانوية
    if (isWrite && Array.isArray(BACKUP_SYNC_DATABASES) && BACKUP_SYNC_DATABASES.length > 0) {
      const syncTasks = BACKUP_SYNC_DATABASES.map(async (dbConfig) => {
        if (dbConfig.url && dbConfig.token) {
          try {
            await queryCustomTursoDirect(dbConfig.url, dbConfig.token, trimmedSql, args);
          } catch (e) {
            console.warn(`Multi-sync to secondary DB (${dbConfig.name}) warning:`, e);
          }
        }
      });
      await Promise.allSettled(syncTasks);
    }
    return res;
  } catch (primaryErr) {
    console.warn('Primary DB unavailable, attempting fallback through backup databases:', primaryErr);
    // التبديل التلقائي السلس للقواعد الثانوية بالترتيب عند تعطل الرئيسية (Failover Chain)
    if (Array.isArray(BACKUP_SYNC_DATABASES) && BACKUP_SYNC_DATABASES.length > 0) {
      for (let i = 0; i < BACKUP_SYNC_DATABASES.length; i++) {
        const dbConfig = BACKUP_SYNC_DATABASES[i];
        if (dbConfig.url && dbConfig.token) {
          try {
            console.log(`Seamlessly failing over to backup database: ${dbConfig.name}`);
            const res = await queryCustomTursoDirect(dbConfig.url, dbConfig.token, trimmedSql, args);
            // إذا كانت عملية كتابة، يتم نسخها أيضاً لباقي القواعد الثانوية
            if (isWrite) {
              BACKUP_SYNC_DATABASES.forEach((otherDb, otherIdx) => {
                if (otherIdx !== i && otherDb.url && otherDb.token) {
                  queryCustomTursoDirect(otherDb.url, otherDb.token, trimmedSql, args).catch(() => {});
                }
              });
            }
            return res;
          } catch (fallbackErr) {
            console.warn(`Backup DB (${dbConfig.name}) also failed:`, fallbackErr);
          }
        }
      }
    }
    throw primaryErr;
  }
}

/**
 * استعلام موجه حصراً للقاعدة الرئيسية (Central Main Database)
 * دون توجيهها للقواعد الفرعية للمدراء، لاستخدامها في مصادقة وإدارة الحسابات
 */
export async function queryMainTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();

  if (isStaticOrNetlifyEnv()) {
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }

  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!res.ok) {
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    }

    const data = await res.json();
    return data;
  } catch {
    clearTimeout(timeoutId);
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }
}

export const DATABASE_SCHEMA_STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL
  );`,
  `CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    branch_name TEXT DEFAULT 'الفرع الرئيسي',
    phone_or_email TEXT,
    is_active INTEGER DEFAULT 1,
    is_new_registration INTEGER DEFAULT 0,
    subscription_type TEXT DEFAULT 'permanent',
    subscription_expires_at TEXT,
    plain_password TEXT,
    allowed_modules TEXT,
    created_at TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS debtors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    amount REAL DEFAULT 0,
    status TEXT DEFAULT 'دين مرتفع',
    user_id INTEGER DEFAULT 1,
    created_at TEXT,
    history TEXT,
    last_debt_date TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS installments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    item TEXT NOT NULL,
    total_amount REAL DEFAULT 0,
    down_payment REAL DEFAULT 0,
    remaining_amount REAL DEFAULT 0,
    monthly_installment_amount REAL DEFAULT 0,
    registration_date TEXT,
    next_due_date TEXT,
    user_id INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    notes TEXT,
    payments TEXT,
    created_at TEXT,
    national_id TEXT,
    address TEXT,
    guarantor_enabled INTEGER DEFAULT 0,
    guarantor_name TEXT,
    guarantor_address TEXT,
    guarantor_job TEXT,
    guarantor_relation TEXT,
    guarantor_phone TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    company_name TEXT,
    item_type TEXT,
    amount REAL DEFAULT 0,
    status TEXT DEFAULT 'active',
    user_id INTEGER DEFAULT 1,
    created_at TEXT,
    history TEXT,
    last_transaction_date TEXT,
    notes TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS user_settings (
    user_id INTEGER PRIMARY KEY,
    settings_json TEXT NOT NULL,
    updated_at TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS databases_registry (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    token TEXT NOT NULL,
    description TEXT,
    is_default INTEGER DEFAULT 0,
    created_at TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS deleted_records (
    id TEXT,
    entity_type TEXT,
    user_id INTEGER,
    deleted_at TEXT,
    PRIMARY KEY (id, entity_type, user_id)
  );`,
  "CREATE INDEX IF NOT EXISTS idx_deleted_records_user ON deleted_records(user_id, entity_type);",
  "ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1;",
  "ALTER TABLE users ADD COLUMN subscription_type TEXT DEFAULT 'permanent';",
  "ALTER TABLE users ADD COLUMN subscription_expires_at TEXT;",
  "ALTER TABLE users ADD COLUMN plain_password TEXT;",
  "ALTER TABLE users ADD COLUMN allowed_modules TEXT;",
  "ALTER TABLE users ADD COLUMN phone_or_email TEXT;",
  "ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;",
  "ALTER TABLE users ADD COLUMN created_at TEXT;",
  "ALTER TABLE debtors ADD COLUMN created_at TEXT;",
  "ALTER TABLE debtors ADD COLUMN history TEXT;",
  "ALTER TABLE debtors ADD COLUMN last_debt_date TEXT;",
  "ALTER TABLE installments ADD COLUMN notes TEXT;",
  "ALTER TABLE installments ADD COLUMN payments TEXT;",
  "ALTER TABLE installments ADD COLUMN created_at TEXT;",
  "ALTER TABLE installments ADD COLUMN national_id TEXT;",
  "ALTER TABLE installments ADD COLUMN address TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;",
  "ALTER TABLE installments ADD COLUMN guarantor_name TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_address TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_job TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;",
  "CREATE INDEX IF NOT EXISTS idx_debtors_user_id ON debtors(user_id);",
  "CREATE INDEX IF NOT EXISTS idx_debtors_name ON debtors(name);",
  "CREATE INDEX IF NOT EXISTS idx_installments_user_id ON installments(user_id);",
  "CREATE INDEX IF NOT EXISTS idx_installments_status ON installments(status);",
  "CREATE INDEX IF NOT EXISTS idx_installments_next_due_date ON installments(next_due_date);",
  "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);",
];

/**
 * تهيئة وتجهيز قاعدة البيانات السحابية بالكامل فوراً
 * لإنشاء كافة جداول الديون والأقساط والمستخدمين والإعدادات
 */
export async function initializeCustomTursoDatabase(
  url: string,
  token: string
): Promise<{ ok: boolean; message: string; count?: number }> {
  if (!url || !token) {
    return { ok: false, message: 'رابط القاعدة أو التوكن غير متوفر' };
  }

  let successCount = 0;
  for (const sql of DATABASE_SCHEMA_STATEMENTS) {
    try {
      await queryCustomTursoDirect(url.trim(), token.trim(), sql, []);
      successCount++;
    } catch {
      // تجاهل أخطاء الأعمدة أو الجداول إذا كانت موجودة مسبقاً (Table/Column already exists)
    }
  }

  return {
    ok: true,
    message: 'تمت تهيئة وتجهيز هيكل قاعدة البيانات لاستقبال البيانات بنجاح',
    count: successCount,
  };
}

/**
 * تهيئة وتجهيز كافة القواعد الاحتياطية والمنفصلة سحابياً والجداول الخاصة بها تلقائياً
 */
export async function bootstrapAllBackupDatabases(): Promise<void> {
  const customDbs = getLocalDatabases();
  const allToBootstrap = [
    ...(Array.isArray(BACKUP_SYNC_DATABASES) ? BACKUP_SYNC_DATABASES : []),
    ...(Array.isArray(BUILTIN_DEDICATED_DATABASES) ? BUILTIN_DEDICATED_DATABASES : []),
    ...customDbs.map((c) => ({ name: c.name, url: c.url, token: c.token })),
  ];
  for (const dbConfig of allToBootstrap) {
    if (dbConfig.url && dbConfig.token) {
      initializeCustomTursoDatabase(dbConfig.url, dbConfig.token).catch((err) => {
        console.warn(`Error initializing db (${dbConfig.name}):`, err);
      });
    }
  }
}

// تشغيل التهيئة التلقائية للقواعد الرديفة فورياً في الخلفية
bootstrapAllBackupDatabases().catch(() => {});

/**
 * فحص الاتصال بقاعدة البيانات واختبار سرعة الاستجابة وتهيئة الجداول تلقائياً (Test Connection & Bootstrap)
 */
export async function testDatabaseConnection(
  url: string,
  token: string,
  autoBootstrap: boolean = true
): Promise<{ ok: boolean; message: string; latencyMs?: number; initialized?: boolean }> {
  if (!url || !token) {
    return { ok: false, message: 'يرجى إدخال رابط قاعدة البيانات ومفتاح التوكن' };
  }

  if (url.includes('app.turso.tech')) {
    return {
      ok: false,
      message: 'تنبيه: الرابط المدخل هو رابط لوحة التحكم (app.turso.tech). يرجى نسخ رابط الاتصال المباشر بالقاعدة والذي يبدأ بـ libsql:// أو ينتهي بـ .turso.io',
    };
  }

  const startTime = Date.now();
  try {
    await queryCustomTursoDirect(url.trim(), token.trim(), 'SELECT 1;', []);
    const latencyMs = Date.now() - startTime;

    if (autoBootstrap) {
      await initializeCustomTursoDatabase(url, token);
      return {
        ok: true,
        message: `تم فحص الاتصال بنجاح وتهيئة كافة جداول الديون والأقساط لاستقبال البيانات فوراً (${latencyMs}ms)`,
        latencyMs,
        initialized: true,
      };
    }

    return { ok: true, message: `الاتصال ناجح واستجابة القاعدة فائقة السرعة (${latencyMs}ms)`, latencyMs };
  } catch (err: any) {
    let errMsg = err?.message || 'فشل الاتصال بقاعدة البيانات، يرجى التأكد من صحة الرابط والتوكن';
    if (errMsg === 'Failed to fetch' || err instanceof TypeError) {
      errMsg = 'تعذر الاتصال بالقاعدة (Failed to fetch). يرجى التأكد من استخدام رابط الاتصال المباشر بصيغة libsql://your-db-org.turso.io وليس رابط متصفح لوحة التحكم (app.turso.tech)';
    }
    return { ok: false, message: errMsg };
  }
}

/**
 * تحليل نتيجة استعلام Turso وتفتيتها إلى مصفوفة كائنات
 */
export function parseQueryResult(res: any): Record<string, any>[] {
  try {
    const result = res?.results?.[0]?.response?.result;
    if (!result || !result.cols || !result.rows) return [];
    const cols = result.cols.map((c: any) => c.name);
    return result.rows.map((rowArr: any[]) => {
      const obj: Record<string, any> = {};
      rowArr.forEach((cell, idx) => {
        const colName = cols[idx];
        if (typeof cell === 'object' && cell !== null) {
          if (cell.type === 'null') {
            obj[colName] = null;
          } else if ('value' in cell) {
            obj[colName] = cell.value;
          } else {
            obj[colName] = null;
          }
        } else {
          obj[colName] = cell;
        }
      });
      return obj;
    });
  } catch {
    return [];
  }
}

export function extractCellValue(cell: any): any {
  if (cell === null || cell === undefined) return null;
  if (typeof cell === 'object') {
    if (cell.type === 'null') return null;
    if ('value' in cell) {
      if (cell.value === null || cell.value === undefined) return null;
      return cell.value;
    }
    if ('type' in cell && !('value' in cell)) return null;
  }
  return cell;
}

export interface DatabaseSyncReport {
  id: string;
  name: string;
  url: string;
  rawUrl?: string;
  token: string;
  isPrimary: boolean;
  isBackupSync?: boolean;
  isDedicated?: boolean;
  ok: boolean;
  users: number;
  debtors: number;
  installments: number;
  suppliers: number;
  latencyMs: number;
  matchedWithPrimary: boolean;
  error?: string;
}

/**
 * فحص وتدقيق حالة المزامنة وأعداد السجلات لجميع القواعد المسجلة دفعة واحدة
 */
export async function auditAllDatabasesSync(): Promise<{
  reports: DatabaseSyncReport[];
  allMatched: boolean;
}> {
  const customDbs = getLocalDatabases();

  // تجميع القواعد: الرئيسية + الثانوية للمزامنة + الثالثة المنفصلة + المخصصة
  const allTargets: {
    id: string;
    name: string;
    url: string;
    token: string;
    rawUrl?: string;
    isPrimary: boolean;
    isBackupSync: boolean;
    isDedicated: boolean;
  }[] = [
    {
      id: 'primary_db',
      name: 'القاعدة الرئيسية (الافتراضية)',
      url: ALDION_DATABASE_CONFIG.url,
      rawUrl: ALDION_DATABASE_CONFIG.rawUrl,
      token: ALDION_DATABASE_CONFIG.token,
      isPrimary: true,
      isBackupSync: false,
      isDedicated: false,
    },
    ...BACKUP_SYNC_DATABASES.map((b, idx) => ({
      id: `backup_db_${idx + 1}`,
      name: b.name,
      url: b.url,
      rawUrl: b.rawUrl,
      token: b.token,
      isPrimary: false,
      isBackupSync: true,
      isDedicated: false,
    })),
    ...BUILTIN_DEDICATED_DATABASES.map((b) => ({
      id: b.id,
      name: b.name,
      url: b.url,
      rawUrl: b.rawUrl,
      token: b.token,
      isPrimary: false,
      isBackupSync: false,
      isDedicated: true,
    })),
    ...customDbs.map((c) => ({
      id: c.id,
      name: c.name,
      url: c.url,
      rawUrl: c.url,
      token: c.token,
      isPrimary: false,
      isBackupSync: false,
      isDedicated: true,
    })),
  ];

  const getCountsForDb = async (url: string, token: string) => {
    const start = Date.now();
    let uRes = await queryCustomTursoDirect(
      url,
      token,
      "SELECT COUNT(*) FROM users WHERE (username IS NOT NULL AND username != 'admin') AND (role IS NULL OR role != 'admin');",
      []
    ).catch(() => null);
    if (!uRes || !uRes.results || !uRes.results[0]?.response?.result?.rows) {
      uRes = await queryCustomTursoDirect(url, token, "SELECT COUNT(*) FROM users WHERE role = 'manager';", []).catch(() => null);
    }
    const dRes = await queryCustomTursoDirect(url, token, 'SELECT COUNT(*) FROM debtors;', []).catch(() => null);
    const iRes = await queryCustomTursoDirect(url, token, 'SELECT COUNT(*) FROM installments;', []).catch(() => null);
    const sRes = await queryCustomTursoDirect(url, token, 'SELECT COUNT(*) FROM suppliers;', []).catch(() => null);
    const latencyMs = Date.now() - start;

    const extractVal = (res: any) => {
      const val = res?.results?.[0]?.response?.result?.rows?.[0]?.[0];
      if (typeof val === 'object' && val !== null && 'value' in val) return Number(val.value);
      return Number(val || 0);
    };

    return {
      users: extractVal(uRes),
      debtors: extractVal(dRes),
      installments: extractVal(iRes),
      suppliers: extractVal(sRes),
      latencyMs,
    };
  };

  let primaryReport: DatabaseSyncReport | null = null;
  const reports: DatabaseSyncReport[] = [];

  for (const target of allTargets) {
    try {
      const counts = await getCountsForDb(target.url, target.token);
      const isMatched = primaryReport
        ? counts.users === primaryReport.users &&
          counts.debtors === primaryReport.debtors &&
          counts.installments === primaryReport.installments &&
          counts.suppliers === primaryReport.suppliers
        : true;

      const report: DatabaseSyncReport = {
        id: target.id,
        name: target.name,
        url: target.url,
        rawUrl: target.rawUrl,
        token: target.token,
        isPrimary: target.isPrimary,
        isBackupSync: target.isBackupSync,
        isDedicated: target.isDedicated,
        ok: true,
        users: counts.users,
        debtors: counts.debtors,
        installments: counts.installments,
        suppliers: counts.suppliers,
        latencyMs: counts.latencyMs,
        matchedWithPrimary: isMatched,
      };

      if (target.isPrimary) {
        primaryReport = report;
      }
      reports.push(report);
    } catch (err: any) {
      reports.push({
        id: target.id,
        name: target.name,
        url: target.url,
        rawUrl: target.rawUrl,
        token: target.token,
        isPrimary: target.isPrimary,
        isBackupSync: target.isBackupSync,
        isDedicated: target.isDedicated,
        ok: false,
        users: 0,
        debtors: 0,
        installments: 0,
        suppliers: 0,
        latencyMs: 0,
        matchedWithPrimary: false,
        error: err?.message || 'فشل الاتصال بالقاعدة',
      });
    }
  }

  const backupReports = reports.filter((r) => r.isBackupSync);
  const allMatched = backupReports.length === 0 || backupReports.every((r) => r.ok && r.matchedWithPrimary);
  return { reports, allMatched };
}

/**
 * فحص الاتصال بكافة القواعد المسجلة بالنظام دفعة واحدة
 */
export async function testAllDatabasesConnection(): Promise<{
  results: { name: string; ok: boolean; message: string; latencyMs?: number }[];
}> {
  const customDbs = getLocalDatabases();
  const allTargets = [
    { name: 'القاعدة الرئيسية (الافتراضية)', url: ALDION_DATABASE_CONFIG.url, token: ALDION_DATABASE_CONFIG.token },
    ...BACKUP_SYNC_DATABASES.map((b) => ({ name: b.name, url: b.url, token: b.token })),
    ...BUILTIN_DEDICATED_DATABASES.map((b) => ({ name: b.name, url: b.url, token: b.token })),
    ...customDbs.map((c) => ({ name: c.name, url: c.url, token: c.token })),
  ];

  const results = [];
  for (const t of allTargets) {
    const res = await testDatabaseConnection(t.url, t.token, true);
    results.push({
      name: t.name,
      ok: res.ok,
      message: res.message,
      latencyMs: res.latencyMs,
    });
  }

  return { results };
}

/**
 * نسخ وتكشيف وصيانة بيانات جميع السجلات من القاعدة الرئيسية إلى جميع القواعد الثانوية
 */
export async function replicateDataToAllDatabases(): Promise<{
  ok: boolean;
  syncedDbsCount: number;
  message: string;
}> {
  const pUrl = ALDION_DATABASE_CONFIG.url;
  const pToken = ALDION_DATABASE_CONFIG.token;

  // 1. قراءة أحدث البيانات الشاملة من القاعدة الرئيسية
  const usersRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM users;', []).catch(() => null);
  const debtorsRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM debtors;', []).catch(() => null);
  const installmentsRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM installments;', []).catch(() => null);
  const suppliersRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM suppliers;', []).catch(() => null);
  const settingsRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM user_settings;', []).catch(() => null);

  const users = usersRes ? parseQueryResult(usersRes) : [];
  const debtors = debtorsRes ? parseQueryResult(debtorsRes) : [];
  const installments = installmentsRes ? parseQueryResult(installmentsRes) : [];
  const suppliers = suppliersRes ? parseQueryResult(suppliersRes) : [];
  const settings = settingsRes ? parseQueryResult(settingsRes) : [];

  const secondaryTargets = [
    ...BACKUP_SYNC_DATABASES,
  ];

  let syncedCount = 0;
  for (const target of secondaryTargets) {
    if (!target.url || !target.token) continue;
    try {
      // تهيئة الجداول في القاعدة المستهدفة أولاً
      await initializeCustomTursoDatabase(target.url, target.token);

      // نسخ المستوردين / المستخدمين
      for (const u of users) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO users (id, username, password, role, branch_name, phone_or_email, is_active, is_new_registration, subscription_type, subscription_expires_at, plain_password, allowed_modules, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             username=excluded.username,
             password=excluded.password,
             role=excluded.role,
             branch_name=excluded.branch_name,
             phone_or_email=excluded.phone_or_email,
             is_active=excluded.is_active,
             is_new_registration=excluded.is_new_registration,
             subscription_type=excluded.subscription_type,
             subscription_expires_at=excluded.subscription_expires_at,
             plain_password=excluded.plain_password,
             allowed_modules=excluded.allowed_modules,
             created_at=excluded.created_at;`,
          [
            u.id,
            u.username,
            u.password,
            u.role || 'user',
            u.branch_name || 'الفرع الرئيسي',
            u.phone_or_email || '',
            u.is_active ?? 1,
            u.is_new_registration ?? 0,
            u.subscription_type || 'permanent',
            u.subscription_expires_at || '',
            u.plain_password || '',
            u.allowed_modules || '',
            u.created_at || '',
          ]
        ).catch(() => {});
      }

      // نسخ المدينين
      for (const d of debtors) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO debtors (id, name, phone, amount, status, user_id, created_at, history, last_debt_date, type)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             name=excluded.name,
             phone=excluded.phone,
             amount=excluded.amount,
             status=excluded.status,
             user_id=excluded.user_id,
             created_at=excluded.created_at,
             history=excluded.history,
             last_debt_date=excluded.last_debt_date,
             type=excluded.type;`,
          [
            d.id,
            d.name,
            d.phone || '',
            d.amount ?? 0,
            d.status || 'دين مرتفع',
            d.user_id ?? 1,
            d.created_at || '',
            d.history || '',
            d.last_debt_date || '',
            d.type || 'debtor',
          ]
        ).catch(() => {});
      }

      // نسخ الأقساط
      for (const inst of installments) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             name=excluded.name,
             phone=excluded.phone,
             item=excluded.item,
             total_amount=excluded.total_amount,
             down_payment=excluded.down_payment,
             remaining_amount=excluded.remaining_amount,
             monthly_installment_amount=excluded.monthly_installment_amount,
             registration_date=excluded.registration_date,
             next_due_date=excluded.next_due_date,
             user_id=excluded.user_id,
             status=excluded.status,
             notes=excluded.notes,
             payments=excluded.payments,
             created_at=excluded.created_at,
             national_id=excluded.national_id,
             address=excluded.address,
             guarantor_enabled=excluded.guarantor_enabled,
             guarantor_name=excluded.guarantor_name,
             guarantor_address=excluded.guarantor_address,
             guarantor_job=excluded.guarantor_job,
             guarantor_relation=excluded.guarantor_relation,
             guarantor_phone=excluded.guarantor_phone;`,
          [
            inst.id,
            inst.name,
            inst.phone || '',
            inst.item || '',
            inst.total_amount ?? 0,
            inst.down_payment ?? 0,
            inst.remaining_amount ?? 0,
            inst.monthly_installment_amount ?? 0,
            inst.registration_date || '',
            inst.next_due_date || '',
            inst.user_id ?? 1,
            inst.status || 'active',
            inst.notes || '',
            inst.payments || '',
            inst.created_at || '',
            inst.national_id || '',
            inst.address || '',
            inst.guarantor_enabled ?? 0,
            inst.guarantor_name || '',
            inst.guarantor_address || '',
            inst.guarantor_job || '',
            inst.guarantor_relation || '',
            inst.guarantor_phone || '',
          ]
        ).catch(() => {});
      }

      // نسخ الموردين
      for (const sup of suppliers) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO suppliers (id, name, phone, company_name, item_type, amount, status, user_id, created_at, history, last_transaction_date, notes)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             name=excluded.name,
             phone=excluded.phone,
             company_name=excluded.company_name,
             item_type=excluded.item_type,
             amount=excluded.amount,
             status=excluded.status,
             user_id=excluded.user_id,
             created_at=excluded.created_at,
             history=excluded.history,
             last_transaction_date=excluded.last_transaction_date,
             notes=excluded.notes;`,
          [
            sup.id,
            sup.name,
            sup.phone || '',
            sup.company_name || '',
            sup.item_type || '',
            sup.amount ?? 0,
            sup.status || 'active',
            sup.user_id ?? 1,
            sup.created_at || '',
            sup.history || '',
            sup.last_transaction_date || '',
            sup.notes || '',
          ]
        ).catch(() => {});
      }

      // نسخ الإعدادات
      for (const st of settings) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO user_settings (user_id, settings_json, updated_at)
           VALUES (?, ?, ?)
           ON CONFLICT(user_id) DO UPDATE SET settings_json=excluded.settings_json, updated_at=excluded.updated_at;`,
          [st.user_id, st.settings_json, st.updated_at || '']
        ).catch(() => {});
      }

      // مطابقة وتطهير السجلات المحذوفة (Mirror Pruning) لضمان تطابق الأعداد 100% بين القاعدتين
      if (users.length > 0) {
        const validUsernames = users.map((u) => `'${String(u.username).replace(/'/g, "''")}'`).filter(Boolean);
        if (validUsernames.length > 0) {
          await queryCustomTursoDirect(
            target.url,
            target.token,
            `DELETE FROM users WHERE username NOT IN (${validUsernames.join(',')}) AND role != 'admin';`,
            []
          ).catch(() => {});
        }
      }

      if (debtors.length > 0) {
        const validDebtorIds = debtors.map((d) => d.id).filter(Boolean);
        if (validDebtorIds.length > 0) {
          await queryCustomTursoDirect(
            target.url,
            target.token,
            `DELETE FROM debtors WHERE id NOT IN (${validDebtorIds.join(',')});`,
            []
          ).catch(() => {});
        }
      }

      if (installments.length > 0) {
        const validInstIds = installments.map((i) => i.id).filter(Boolean);
        if (validInstIds.length > 0) {
          await queryCustomTursoDirect(
            target.url,
            target.token,
            `DELETE FROM installments WHERE id NOT IN (${validInstIds.join(',')});`,
            []
          ).catch(() => {});
        }
      }

      if (suppliers.length > 0) {
        const validSupIds = suppliers.map((s) => s.id).filter(Boolean);
        if (validSupIds.length > 0) {
          await queryCustomTursoDirect(
            target.url,
            target.token,
            `DELETE FROM suppliers WHERE id NOT IN (${validSupIds.join(',')});`,
            []
          ).catch(() => {});
        }
      }

      syncedCount++;
    } catch (e) {
      console.warn(`Error replicating data to target DB (${target.name}):`, e);
    }
  }

  return {
    ok: true,
    syncedDbsCount: syncedCount,
    message: `تم نسخ وتحديث وتوحيد كافة بيانات الديون والأقساط والموردين والمستخدمين بنجاح في (${syncedCount}) قاعدة ثانوية!`,
  };
}

/**
 * حذف شامل وآمن للمدير أو الحساب التجريبي من القواعد السحابية والذاكرة المؤقتة مع عزل تام للقواعد
 */
export async function deleteUserFromAllDatabases(
  userId: number,
  username?: string,
  phoneOrEmail?: string
): Promise<{ ok: boolean; message: string }> {
  const pUrl = ALDION_DATABASE_CONFIG.url;
  const pToken = ALDION_DATABASE_CONFIG.token;

  const targets = [
    { url: pUrl, token: pToken, name: 'Primary DB' },
    ...BACKUP_SYNC_DATABASES.map((b) => ({ url: b.url, token: b.token, name: b.name })),
    ...(THIRD_DATABASE_CONFIG.url && THIRD_DATABASE_CONFIG.token
      ? [{ url: THIRD_DATABASE_CONFIG.url, token: THIRD_DATABASE_CONFIG.token, name: 'Third DB (alidion2)' }]
      : []),
    ...getLocalDatabases().map((c) => ({ url: c.url, token: c.token, name: c.name })),
  ];

  const trimmedUser = (username || '').trim();
  const trimmedPhone = (phoneOrEmail || '').trim();

  const deletePromises = targets.map(async (target) => {
    if (!target.url || !target.token) return;
    try {
      // 1. استعلام أولاً عن الحساب بالاسم أو رقم الهاتف لاستخراج الـ id المحلي الدقيق داخل هذا السيرفر بعينه
      const selectRes = await queryCustomTursoDirect(
        target.url,
        target.token,
        `SELECT id FROM users WHERE (username IS NOT NULL AND LOWER(TRIM(username)) = LOWER(TRIM(?))) OR (? != '' AND phone_or_email IS NOT NULL AND TRIM(phone_or_email) = TRIM(?));`,
        [trimmedUser, trimmedPhone, trimmedPhone]
      );

      const rows = selectRes.results?.[0]?.response?.result?.rows || [];
      const matchedIds = new Set<number>();
      if (userId) matchedIds.add(Number(userId));

      for (const r of rows) {
        const localId = r[0]?.value;
        if (localId !== undefined && localId !== null) {
          matchedIds.add(Number(localId));
        }
      }

      for (const targetId of matchedIds) {
        // حذف شامل لكافة البيانات المرتبطة برقم المعرف الخاص بالمدير
        await queryCustomTursoDirect(target.url, target.token, `DELETE FROM debtors WHERE user_id = ?;`, [targetId]).catch(() => {});
        await queryCustomTursoDirect(target.url, target.token, `DELETE FROM installments WHERE user_id = ?;`, [targetId]).catch(() => {});
        await queryCustomTursoDirect(target.url, target.token, `DELETE FROM suppliers WHERE user_id = ?;`, [targetId]).catch(() => {});
        await queryCustomTursoDirect(target.url, target.token, `DELETE FROM user_settings WHERE user_id = ?;`, [targetId]).catch(() => {});
        await queryCustomTursoDirect(target.url, target.token, `DELETE FROM users WHERE id = ?;`, [targetId]).catch(() => {});
      }

      // 2. ضمان التطهير باسم المستخدم في حال تعذر الاستعلام بالـ ID
      if (trimmedUser) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `DELETE FROM users WHERE LOWER(TRIM(username)) = LOWER(TRIM(?)) AND role != 'admin';`,
          [trimmedUser]
        ).catch(() => {});
      }
    } catch (err) {
      console.warn(`Error deleting user ${trimmedUser || userId} from ${target.name}:`, err);
    }
  });

  await Promise.allSettled(deletePromises);

  // 3. مسح الحساب من الذاكرة المؤقتة المحلية
  try {
    const raw = localStorage.getItem('local_managers_list');
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list)) {
        const filtered = list.filter((m: any) => m.id !== userId && m.username?.trim().toLowerCase() !== trimmedUser.toLowerCase());
        localStorage.setItem('local_managers_list', JSON.stringify(filtered));
      }
    }
  } catch {}

  return {
    ok: true,
    message: 'تم حذف الحساب بنجاح من كافة القواعد السحابية والذاكرة المحلية بأمان تام',
  };
}

/**
 * فحص وتدقيق مطابقة أعداد البيانات بين القاعدة الرئيسية والقاعدة الثانوية ببيانات حية
 */
export async function verifyDataSyncMatch(): Promise<{
  ok: boolean;
  primaryCounts: { users: number; debtors: number; installments: number; suppliers: number };
  secondaryCounts: { users: number; debtors: number; installments: number; suppliers: number };
  matched: boolean;
}> {
  const audit = await auditAllDatabasesSync();
  const primary = audit.reports.find((r) => r.isPrimary);
  const secondary = audit.reports.find((r) => !r.isPrimary && r.ok);

  const primaryCounts = {
    users: primary?.users || 0,
    debtors: primary?.debtors || 0,
    installments: primary?.installments || 0,
    suppliers: primary?.suppliers || 0,
  };

  const secondaryCounts = {
    users: secondary?.users || 0,
    debtors: secondary?.debtors || 0,
    installments: secondary?.installments || 0,
    suppliers: secondary?.suppliers || 0,
  };

  const matched =
    primaryCounts.users === secondaryCounts.users &&
    primaryCounts.debtors === secondaryCounts.debtors &&
    primaryCounts.installments === secondaryCounts.installments &&
    primaryCounts.suppliers === secondaryCounts.suppliers;

  return {
    ok: Boolean(primary?.ok && secondary?.ok),
    primaryCounts,
    secondaryCounts,
    matched,
  };
}

// ---------------------- MULTI-DATABASE REGISTRY HELPERS ----------------------

export function getLocalDatabases(): DatabaseAccount[] {
  try {
    const raw = localStorage.getItem('aldion_database_accounts');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function setLocalDatabases(dbs: DatabaseAccount[]) {
  try {
    localStorage.setItem('aldion_database_accounts', JSON.stringify(dbs));
  } catch (e) {
    console.error("Error saving local databases:", e);
  }
}

export function getActiveUserDatabaseAccount(): DatabaseAccount | null {
  try {
    const user = getLocalSession();
    if (user && user.databaseId) {
      if (user.databaseId === 'builtin_third_alidion2' || user.databaseId === 'alidion2' || user.databaseId === 'third') {
        return {
          id: 'builtin_third_alidion2',
          name: 'القاعدة الثالثة المنفصلة (alidion2)',
          url: THIRD_DATABASE_CONFIG.url,
          token: THIRD_DATABASE_CONFIG.token,
          description: 'قاعدة بيانات منفصلة تماماً مخصصة لمدراء محددين',
        };
      }
      if (user.databaseId === 'builtin_secondary' || user.databaseId === 'secondary') {
        return {
          id: 'builtin_secondary',
          name: 'القاعدة الثانوية (AWS Mumbai / aldin-2026)',
          url: SECONDARY_DATABASE_CONFIG.url,
          token: SECONDARY_DATABASE_CONFIG.token,
          description: 'القاعدة الثانوية الرديفة للمزامنة',
        };
      }
      const dbs = getLocalDatabases();
      const found = dbs.find((d) => d.id === user.databaseId);
      if (found && found.url && found.token) {
        return found;
      }
    }
  } catch {}
  return null;
}

export async function fetchDatabasesFromCloud(): Promise<DatabaseAccount[]> {
  try {
    let res;
    try {
      res = await queryEmbeddedEncryptedTurso('SELECT id, name, url, token, description, is_default, created_at FROM databases_registry ORDER BY created_at DESC;', []);
    } catch {
      await queryEmbeddedEncryptedTurso(`CREATE TABLE IF NOT EXISTS databases_registry (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        url TEXT NOT NULL,
        token TEXT NOT NULL,
        description TEXT,
        is_default INTEGER DEFAULT 0,
        created_at TEXT
      );`, []).catch(() => {});
      return getLocalDatabases();
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }

    const dbs: DatabaseAccount[] = rows.map((r) => {
      const getVal = (cell: any) => {
        if (!cell) return undefined;
        if (typeof cell === 'object') {
          if (cell.type === 'null') return undefined;
          if ('value' in cell) return cell.value ?? undefined;
          return undefined;
        }
        return cell;
      };

      return {
        id: String(getVal(r[0]) || ''),
        name: String(getVal(r[1]) || ''),
        url: String(getVal(r[2]) || ''),
        token: String(getVal(r[3]) || ''),
        description: getVal(r[4]) ? String(getVal(r[4])) : '',
        isDefault: Boolean(getVal(r[5])),
        createdAt: getVal(r[6]) ? String(getVal(r[6])) : undefined,
      };
    });

    setLocalDatabases(dbs);
    for (const db of dbs) {
      if (db.url && db.token) {
        initializeCustomTursoDatabase(db.url, db.token).catch(() => {});
      }
    }
    return dbs;
  } catch (e) {
    console.warn("Could not fetch databases from cloud:", e);
    return getLocalDatabases();
  }
}

export async function syncDatabasesToCloud(dbs: DatabaseAccount[]): Promise<void> {
  setLocalDatabases(dbs);
  try {
    await queryEmbeddedEncryptedTurso(`CREATE TABLE IF NOT EXISTS databases_registry (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      url TEXT NOT NULL,
      token TEXT NOT NULL,
      description TEXT,
      is_default INTEGER DEFAULT 0,
      created_at TEXT
    );`, []).catch(() => {});

    for (const dbAccount of dbs) {
      if (dbAccount.url && dbAccount.token) {
        initializeCustomTursoDatabase(dbAccount.url, dbAccount.token).catch(() => {});
      }
      const now = dbAccount.createdAt || new Date().toISOString();
      await queryEmbeddedEncryptedTurso(
        `INSERT INTO databases_registry (id, name, url, token, description, is_default, created_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?) 
         ON CONFLICT(id) DO UPDATE SET 
           name = excluded.name, 
           url = excluded.url, 
           token = excluded.token, 
           description = excluded.description, 
           is_default = excluded.is_default;`,
        [dbAccount.id, dbAccount.name, dbAccount.url, dbAccount.token, dbAccount.description || '', dbAccount.isDefault ? 1 : 0, now]
      );
    }
  } catch (e) {
    console.warn("Could not sync databases to cloud:", e);
  }
}

export async function deleteDatabaseFromCloud(dbId: string): Promise<void> {
  const current = getLocalDatabases().filter((d) => d.id !== dbId);
  setLocalDatabases(current);

  // 1. Reset any local cached managers assigned to this deleted database to null (default DB)
  try {
    const rawMgrs = localStorage.getItem('local_managers_list');
    if (rawMgrs) {
      const list = JSON.parse(rawMgrs);
      if (Array.isArray(list)) {
        const updatedList = list.map((m: any) => (m.databaseId === dbId ? { ...m, databaseId: null } : m));
        localStorage.setItem('local_managers_list', JSON.stringify(updatedList));
      }
    }
  } catch (e) {
    console.warn("Error updating local managers on db delete:", e);
  }

  // 2. Delete from cloud database registry and reset users assigned to this database
  try {
    await queryEmbeddedEncryptedTurso('DELETE FROM databases_registry WHERE id = ?;', [dbId]);
    await queryEmbeddedEncryptedTurso('UPDATE users SET database_id = NULL WHERE database_id = ?;', [dbId]).catch(() => {});
  } catch (e) {
    console.warn("Could not delete database from cloud:", e);
  }
}

export function isStaticOrNetlifyEnv(): boolean {
  if (typeof window === 'undefined') return false;
  const origin = window.location.origin || '';
  // If on netlify, github.io, capacitor, file, or any non-localhost / non-run.app host
  return !origin.includes('localhost') && !origin.includes('127.0.0.1') && !origin.includes('run.app');
}

/**
 * Enterprise Resilient Database Proxy:
 * 1. إذا كان التطبيق يعمل على Netlify أو استضافة ثابتة أو PWA، يتصل مباشرة بالمحرك المشفر فائق السرعة دون أي تأخير أو خادم وسيط.
 * 2. إذا كان يعمل محلياً في بيئة التطوير، يحاول أولاً الاتصال عبر الخادم المحمي (API Proxy).
 */
export async function queryTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();

  // إذا كان المستخدم ينتمي لقاعدة بيانات مخصصة تم تحديدها له من قبل الإدارة العامة
  const customDb = getActiveUserDatabaseAccount();
  if (customDb && customDb.url && customDb.token) {
    return await queryCustomTursoDirect(customDb.url, customDb.token, trimmedSql, args);
  }

  // على Netlify والتطبيقات الخارجية: اتصال فوري ومباشر بالمحرك المشفر السريع
  if (isStaticOrNetlifyEnv()) {
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }

  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    // إذا أعاد الخادم صفحة HTML أو خطأ توجيه (302/404/PWA Standalone redirect)
    const contentType = res.headers.get('content-type') || '';
    if (!res.ok || !contentType.includes('application/json')) {
      // التحول التلقائي للمحرك المدمج المشفر
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في تنفيذ استعلام القاعدة');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    // إذا تعذر الوصول للخادم بسبب CORS أو انقطاع أو تشغيل في بيئة PWA مستقلة
    try {
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    } catch (fallbackErr: any) {
      if (err.name === 'AbortError' || fallbackErr.name === 'AbortError') {
        throw new Error('انتهت مهلة الاتصال بالخادم، يرجى التحقق من اتصال الإنترنت');
      }
      throw fallbackErr || err;
    }
  }
}

// ---------------------- LOCAL STORAGE HELPERS ----------------------

export function getLocalDebtors(userId: number): Debtor[] | null {
  const data = localStorage.getItem(`debtors_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalDebtors(userId: number, debtors: Debtor[]) {
  localStorage.setItem(`debtors_user_${userId}`, JSON.stringify(debtors));
}

// Local Storage for Installments (نظام الأقساط المنفصل)
export function getLocalInstallments(userId: number): InstallmentRecord[] | null {
  const data = localStorage.getItem(`installments_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalInstallments(userId: number, installments: InstallmentRecord[]) {
  localStorage.setItem(`installments_user_${userId}`, JSON.stringify(installments));
}

export function getLocalUsers(): User[] | null {
  try {
    const data = localStorage.getItem("local_users");
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function setLocalUsers(users: User[]) {
  try {
    const safeUsers = users.map(({ password: _, ...u }) => u as User);
    localStorage.setItem("local_users", JSON.stringify(safeUsers));
  } catch {}
}

export const DEFAULT_USER: User = {
  id: 1,
  username: 'admin',
  role: 'admin',
  branch_name: 'الفرع الرئيسي',
  isActive: true,
  subscriptionType: 'permanent',
};

export function getLocalSession(): User | null {
  try {
    const data = localStorage.getItem("session_user");
    if (!data) return null;
    const user: User = JSON.parse(data);
    if (!user || !user.id) return null;

    // Cryptographic Session Signature Check to prevent console tampering
    const signature = localStorage.getItem("session_user_sig");
    const isValidSig = verifyLocalSessionUser(user, signature);
    if (!isValidSig) {
      console.warn("Invalid or tampered session detected. Logging out.");
      localStorage.removeItem("session_user");
      localStorage.removeItem("session_user_sig");
      return null;
    }
    // Auto-backfill signature for legitimate existing sessions
    if (!signature) {
      localStorage.setItem("session_user_sig", signLocalSessionUser(user));
    }

    if (user.role !== 'admin' && user.id) {
      const forceLogout = localStorage.getItem(`force_logout_user_${user.id}`);
      if (forceLogout) {
        localStorage.removeItem("session_user");
        localStorage.removeItem("session_user_sig");
        return null;
      }
      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        const managers: Manager[] = JSON.parse(managersData);
        const found = managers.find((m) => m.id === user.id);
        if (found) {
          if (found.isActive === false) {
            localStorage.removeItem("session_user");
            localStorage.removeItem("session_user_sig");
            return null;
          }
          if (found.subscriptionType) {
            user.subscriptionType = found.subscriptionType;
          }
        }
      }
    }
    if (!user.password) {
      const cachedPass = getSecuredPassword(user.id) || getSecuredPassword(user.username);
      if (cachedPass) {
        user.password = cachedPass;
      }
    }
    return user;
  } catch {
    return null;
  }
}

export function setLocalSession(user: User | null) {
  if (user) {
    localStorage.setItem("session_user", JSON.stringify(user));
    localStorage.setItem("session_user_sig", signLocalSessionUser(user));
    if (user.password) {
      setSecuredPassword(user.id, user.password);
      setSecuredPassword(user.username, user.password);
    }
    // حفظ دائم في خزينة الهاتف لتسجيل الدخول في وضع انقطاع السيرفر أو حذفه
    saveOfflineUserVault(user);
  } else {
    localStorage.removeItem("session_user");
    localStorage.removeItem("session_user_sig");
  }
}

/**
 * Checks if a given userId or active session is trial/local/demo mode.
 * Any data belonging to trial/local users MUST NEVER be synced or written to cloud DB.
 */
export function isTrialOrLocalUser(userId?: number, entity?: any): boolean {
  if (entity?.isDemo || (entity?.id && Number(entity.id) < 0)) {
    return true;
  }
  if (!userId || userId === 999999 || userId <= 0) {
    return true;
  }
  const session = getLocalSession();
  if (session) {
    if (
      session.subscriptionType === 'trial' ||
      session.subscriptionType === 'local_permanent' ||
      session.role === 'trial' ||
      Boolean(session.isNewRegistration) ||
      session.id === 999999
    ) {
      return true;
    }
  }
  return false;
}

export interface OfflineUserVaultEntry {
  id: number;
  username: string;
  role: string;
  branch_name: string;
  phoneOrEmail?: string;
  password?: string;
  passwordHash?: string;
  isActive: boolean;
  isNewRegistration?: boolean;
  subscriptionType?: SubscriptionType;
  subscriptionExpiresAt?: string | null;
  allowedModules?: ManagerModuleAccess;
  layoutTheme?: AppLayoutTheme;
  birthDate?: string;
  databaseId?: string | null;
  isSuspended?: boolean;
  suspendMessage?: string;
  savedAt: number;
}

const OFFLINE_USERS_VAULT_KEY = 'aldion_offline_user_vault';

/**
 * حفظ نسخة دائمة ومحمية من بيانات المستخدم وكلمة المرور في ذاكرة الهاتف
 * للاستخدام عند تعطل أو حذف السيرفر السحابي
 */
export function saveOfflineUserVault(user: User, plainPassword?: string): void {
  try {
    if (!user || !user.id) return;
    const raw = localStorage.getItem(OFFLINE_USERS_VAULT_KEY);
    let list: OfflineUserVaultEntry[] = [];
    if (raw) {
      try {
        list = JSON.parse(raw);
        if (!Array.isArray(list)) list = [];
      } catch {
        list = [];
      }
    }

    const effectivePass = plainPassword || user.password || getSecuredPassword(user.id) || getSecuredPassword(user.username);
    if (effectivePass) {
      setSecuredPassword(user.id, effectivePass);
      setSecuredPassword(user.username, effectivePass);
    }

    const entry: OfflineUserVaultEntry = {
      id: user.id,
      username: user.username,
      role: user.role,
      branch_name: user.branch_name || user.username || 'الفرع الرئيسي',
      phoneOrEmail: user.phoneOrEmail,
      password: effectivePass,
      isActive: user.isActive !== false,
      isNewRegistration: Boolean(user.isNewRegistration),
      subscriptionType: user.subscriptionType || 'permanent',
      subscriptionExpiresAt: user.subscriptionExpiresAt,
      allowedModules: user.allowedModules || 'both',
      layoutTheme: user.layoutTheme || 'classic',
      birthDate: user.birthDate,
      databaseId: user.databaseId || null,
      isSuspended: Boolean(user.isSuspended),
      suspendMessage: user.suspendMessage,
      savedAt: Date.now(),
    };

    const filtered = list.filter(
      (item) => item.id !== user.id && item.username?.toLowerCase() !== user.username?.toLowerCase()
    );
    filtered.unshift(entry);
    localStorage.setItem(OFFLINE_USERS_VAULT_KEY, JSON.stringify(filtered));
  } catch (e) {
    console.warn('Could not save offline user vault:', e);
  }
}

export function getOfflineUserVault(): OfflineUserVaultEntry[] {
  try {
    const raw = localStorage.getItem(OFFLINE_USERS_VAULT_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

/**
 * التحقق الصامت والسريع من بيانات المستخدم عبر الذاكرة المحلية للهاتف
 * عند حذف السيرفر أو انقطاع الاتصال بالقاعدة
 */
export function findMatchingOfflineUser(identifier: string, enteredPass: string): User | null {
  try {
    if (!identifier || !enteredPass) return null;
    const cleanId = identifier.trim().toLowerCase();
    const cleanIdNoSpaces = cleanId.replace(/\s+/g, '');
    const cleanPass = enteredPass.trim();

    const vault = getOfflineUserVault();
    for (const entry of vault) {
      const uName = (entry.username || '').trim().toLowerCase();
      const uNameNoSpaces = uName.replace(/\s+/g, '');
      const uPhone = (entry.phoneOrEmail || '').trim().toLowerCase();
      const uPhoneNoSpaces = uPhone.replace(/\s+/g, '');
      const uBranch = (entry.branch_name || '').trim().toLowerCase();

      const isIdMatch =
        uName === cleanId ||
        uNameNoSpaces === cleanIdNoSpaces ||
        uPhone === cleanId ||
        uPhoneNoSpaces === cleanIdNoSpaces ||
        uBranch === cleanId;

      if (!isIdMatch) continue;

      const storedPlain = entry.password || getSecuredPassword(entry.id) || getSecuredPassword(entry.username);
      let isPassMatch = false;

      if (storedPlain && storedPlain === cleanPass) {
        isPassMatch = true;
      } else if (
        entry.passwordHash &&
        (entry.passwordHash.startsWith('$2a$') ||
          entry.passwordHash.startsWith('$2b$') ||
          entry.passwordHash.startsWith('$2y$'))
      ) {
        try {
          isPassMatch = bcrypt.compareSync(cleanPass, entry.passwordHash);
        } catch {}
      }

      if (isPassMatch) {
        return {
          id: entry.id,
          username: entry.username,
          role: entry.role as any,
          branch_name: entry.branch_name,
          phoneOrEmail: entry.phoneOrEmail,
          password: cleanPass,
          isActive: entry.isActive !== false,
          isNewRegistration: entry.isNewRegistration,
          subscriptionType: entry.subscriptionType,
          subscriptionExpiresAt: entry.subscriptionExpiresAt,
          allowedModules: entry.allowedModules,
          layoutTheme: entry.layoutTheme,
          birthDate: entry.birthDate,
          databaseId: entry.databaseId,
          isSuspended: entry.isSuspended,
          suspendMessage: entry.suspendMessage,
        };
      }
    }

    // فحص احتياطي إضافي للحسابات المسجلة في الكاش المحلي
    const trialRaw = localStorage.getItem('local_trial_users_cache');
    if (trialRaw) {
      try {
        const trials: User[] = JSON.parse(trialRaw);
        const found = trials.find(
          (u) =>
            ((u.username && u.username.toLowerCase() === cleanId) ||
              (u.phoneOrEmail && u.phoneOrEmail.replace(/\s+/g, '') === cleanIdNoSpaces)) &&
            u.password === cleanPass
        );
        if (found) return found;
      } catch {}
    }

    const mgrRaw = localStorage.getItem('local_managers_list');
    if (mgrRaw) {
      try {
        const mgrs: Manager[] = JSON.parse(mgrRaw);
        for (const m of mgrs) {
          const mName = (m.username || '').trim().toLowerCase();
          const mPhone = (m.phoneOrEmail || '').trim().toLowerCase();
          if (mName === cleanId || mPhone === cleanId || mPhone.replace(/\s+/g, '') === cleanIdNoSpaces) {
            const mPass = m.plainPassword || getSecuredPassword(m.id) || getSecuredPassword(m.username);
            if (mPass && mPass === cleanPass) {
              return {
                id: m.id,
                username: m.username,
                role: 'manager',
                branch_name: m.branch,
                phoneOrEmail: m.phoneOrEmail,
                password: cleanPass,
                isActive: m.isActive !== false,
                isNewRegistration: m.isNewRegistration,
                subscriptionType: m.subscriptionType,
                subscriptionExpiresAt: m.subscriptionExpiresAt,
                allowedModules: m.allowedModules,
                layoutTheme: m.layoutTheme,
                birthDate: m.birthDate,
                databaseId: m.databaseId,
                isSuspended: m.isSuspended,
                suspendMessage: m.suspendMessage,
              };
            }
          }
        }
      } catch {}
    }

    return null;
  } catch (err) {
    console.warn('Error matching offline user:', err);
    return null;
  }
}

/**
 * تسجيل خروج آمن وتطهير فوري للذاكرة والجلسة
 */
export function secureCleanLogout() {
  localStorage.removeItem("session_user");
  localStorage.removeItem("session_user_sig");
  sessionStorage.clear();
  if (sessionBroadcastChannel) {
    try {
      sessionBroadcastChannel.postMessage({ type: 'SESSION_CLEAN_LOGOUT', timestamp: Date.now() });
    } catch {}
  }
}

// Multi-tab synchronization
export const sessionBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('submanager_auth_sync')
    : null;

export const debtorsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('debtors_realtime_sync')
    : null;

export const installmentsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('installments_realtime_sync')
    : null;

export const suppliersBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('suppliers_realtime_sync')
    : null;

export const settingsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('settings_realtime_sync')
    : null;

export function broadcastDebtorsChange(userId: number, actionType?: string, payload?: any) {
  try {
    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.postMessage({
        type: 'DEBTORS_UPDATED',
        userId,
        actionType,
        payload,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastInstallmentsChange(userId: number, actionType?: string, payload?: any) {
  try {
    if (installmentsBroadcastChannel) {
      installmentsBroadcastChannel.postMessage({
        type: 'INSTALLMENTS_UPDATED',
        userId,
        actionType,
        payload,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastSuppliersChange(userId: number, actionType?: string, payload?: any) {
  try {
    if (suppliersBroadcastChannel) {
      suppliersBroadcastChannel.postMessage({
        type: 'SUPPLIERS_UPDATED',
        userId,
        actionType,
        payload,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastSettingsChange(userId: number, settings: AppSettings) {
  try {
    if (settingsBroadcastChannel) {
      settingsBroadcastChannel.postMessage({
        type: 'SETTINGS_UPDATED',
        userId,
        settings,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastManagerStatusChange(targetUserId: number, isActive: boolean, reason?: string) {
  try {
    const current = getLocalSession();
    // Shield Admin from accidental logout when deleting/suspending a submanager whose ID collides with Admin (e.g. ID 1)
    if (current && (current.role === 'admin' || current.username?.toLowerCase() === 'admin' || current.id === 1)) {
      if (current.id === targetUserId || targetUserId === 1) {
        return;
      }
    }

    if (!isActive) {
      localStorage.setItem(
        `force_logout_user_${targetUserId}`,
        JSON.stringify({
          timestamp: Date.now(),
          reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
        })
      );
      if (current && current.id === targetUserId && current.role !== 'admin') {
        localStorage.removeItem("session_user");
      }
    } else {
      localStorage.removeItem(`force_logout_user_${targetUserId}`);
    }

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.postMessage({
        type: isActive ? 'MANAGER_ACTIVATED' : 'FORCE_LOGOUT',
        targetUserId,
        reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
      });
    }
  } catch (e) {
    console.warn('Broadcast error:', e);
  }
}

export function getLocalManagers(): Manager[] | null {
  try {
    const data = localStorage.getItem("local_managers_list");
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function setLocalManagers(managers: Manager[]) {
  try {
    localStorage.setItem("local_managers_list", JSON.stringify(managers));
  } catch {}
}

export const DEFAULT_SETTINGS: AppSettings = {
  enableDebtAlerts: true,
  alertDaysThreshold: 1,
  highDebtThreshold: 25000,
  numberFormat: 'english',
  language: 'ar',
  currency: 'IQD',
  layoutTheme: 'classic',
  fontSize: 'default',
  enableUpdateNotice: false,
  updateNoticeMessage: 'يتوفر تحديث جديد للنظام، يرجى اضغط زر تنزيل التحديث الآن لتثبيت النسخة الجديدة.',
  updateNoticeTargetVersion: 'v3.5',
  globalEmergencyFreeze: false,
  globalEmergencyFreezeMessage: 'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة، يرجى المراجعة',
  companyName: '',
  companyPhone: '',
  companyAddress: '',
  enableElectronicPayment: false,
  mastercardNumber: '',
  electronicPaymentNotes: '',
  sensitiveActionLockEnabled: false,
  sensitiveActionPin: '1',
  sensitiveActionProtectManagers: true,
  sensitiveActionProtectDebtors: true,
  sensitiveActionProtectReset: true,
};

export function getLocalSettings(userId: number): AppSettings {
  try {
    const raw = localStorage.getItem(`app_settings_user_${userId}`);
    const globalLang = (localStorage.getItem('dftr_app_language') as any) || 'ar';
    const globalCurr = (localStorage.getItem('dftr_app_currency') as any) || 'IQD';
    const globalNumF = (localStorage.getItem('dftr_app_number_format') as any) || 'english';
    const globalFontSize = (localStorage.getItem('aldion_app_font_size') as any) || 'default';

    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enableDebtAlerts: parsed.enableDebtAlerts ?? true,
        alertDaysThreshold: parsed.alertDaysThreshold ?? 1,
        highDebtThreshold: parsed.highDebtThreshold ?? 25000,
        numberFormat: parsed.numberFormat ?? globalNumF,
        language: parsed.language ?? globalLang,
        currency: parsed.currency ?? globalCurr,
        layoutTheme: 'classic',
        fontSize: parsed.fontSize ?? globalFontSize,
        enableUpdateNotice: parsed.enableUpdateNotice ?? false,
        updateNoticeMessage: parsed.updateNoticeMessage || 'يتوفر تحديث جديد للنظام، يرجى اضغط زر تنزيل التحديث الآن لتثبيت النسخة الجديدة.',
        updateNoticeTargetVersion: parsed.updateNoticeTargetVersion || 'v3.5',
        globalEmergencyFreeze: parsed.globalEmergencyFreeze ?? false,
        globalEmergencyFreezeMessage: parsed.globalEmergencyFreezeMessage || 'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة، يرجى المراجعة',
        companyName: parsed.companyName !== undefined ? parsed.companyName : '',
        companyPhone: parsed.companyPhone || '',
        companyAddress: parsed.companyAddress || '',
        enableElectronicPayment: parsed.enableElectronicPayment ?? false,
        mastercardNumber: parsed.mastercardNumber || '',
        electronicPaymentNotes: parsed.electronicPaymentNotes || '',
        sensitiveActionLockEnabled: parsed.sensitiveActionLockEnabled ?? false,
        sensitiveActionPin: parsed.sensitiveActionPin !== undefined ? parsed.sensitiveActionPin : '1',
        sensitiveActionProtectManagers: parsed.sensitiveActionProtectManagers ?? true,
        sensitiveActionProtectDebtors: parsed.sensitiveActionProtectDebtors ?? true,
        sensitiveActionProtectReset: parsed.sensitiveActionProtectReset ?? true,
      };
    }
  } catch (e) {
    console.error("Error reading local settings:", e);
  }
  const globalFontSize = (localStorage.getItem('aldion_app_font_size') as any) || 'default';
  return { ...DEFAULT_SETTINGS, layoutTheme: 'classic', fontSize: globalFontSize };
}

export function setLocalSettings(userId: number, settings: AppSettings) {
  try {
    localStorage.setItem(`app_settings_user_${userId}`, JSON.stringify(settings));
    if (settings.layoutTheme) {
      localStorage.setItem('dftr_app_theme', settings.layoutTheme);
    }
    if (settings.fontSize) {
      localStorage.setItem('aldion_app_font_size', settings.fontSize);
    }
  } catch (e) {
    console.error("Error saving local settings:", e);
  }
}

export function getLocalDebtorDates(userId: number): Record<number, string> {
  try {
    const raw = localStorage.getItem(`debtor_dates_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorDates(userId: number, dates: Record<number, string>) {
  try {
    localStorage.setItem(`debtor_dates_user_${userId}`, JSON.stringify(dates));
  } catch (e) {
    console.error("Error saving debtor dates:", e);
  }
}

export function getLocalDebtorHistory(userId: number): Record<number, DebtorTransaction[]> {
  try {
    const raw = localStorage.getItem(`debtor_history_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorHistory(userId: number, historyMap: Record<number, DebtorTransaction[]>) {
  try {
    localStorage.setItem(`debtor_history_user_${userId}`, JSON.stringify(historyMap));
  } catch (e) {
    console.error("Error saving debtor history:", e);
  }
}

/**
 * مزامنة الإعدادات (اللغة، العملة، الأرقام، التنبيهات، السقف) سحابياً لكل مستخدم/مدير فرعي
 */
export async function syncSettingsToCloud(userId: number, settings: AppSettings): Promise<void> {
  if (!userId || userId === 999999) return; // الحساب التجريبي محلي فقط
  try {
    const json = JSON.stringify(settings);
    const now = new Date().toISOString();
    await queryTurso(
      `INSERT INTO user_settings (user_id, settings_json, updated_at) 
       VALUES (?, ?, ?) 
       ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
      [userId, json, now]
    );
  } catch (err: any) {
    try {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`);
      const json = JSON.stringify(settings);
      const now = new Date().toISOString();
      await queryTurso(
        `INSERT INTO user_settings (user_id, settings_json, updated_at) 
         VALUES (?, ?, ?) 
         ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
        [userId, json, now]
      );
    } catch (e) {
      console.warn("Could not sync settings to cloud:", e);
    }
  }
}

/**
 * جلب الإعدادات السحابية للمستخدم عند تسجيل الدخول أو فتح الحساب من جهاز آخر
 */
export async function fetchSettingsFromCloud(userId: number): Promise<AppSettings | null> {
  if (!userId || userId === 999999) return null;
  try {
    let res;
    try {
      res = await queryTurso(
        `SELECT settings_json FROM user_settings WHERE user_id = ? LIMIT 1;`,
        [userId]
      );
    } catch {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`).catch(() => {});
      return null;
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }
    if (rows.length > 0 && rows[0][0]) {
      const val = rows[0][0]?.value ?? rows[0][0];
      if (typeof val === 'string') {
        return JSON.parse(val) as AppSettings;
      }
    }
  } catch (err) {
    console.warn("Could not fetch settings from cloud:", err);
  }
  return null;
}

// ----------------------------------------------------
// SUPPLIERS CLOUD & LOCAL STORAGE FUNCTIONS (الموردين والشركات)
// ----------------------------------------------------

export function sanitizeSupplier(s: any): Supplier {
  if (!s || typeof s !== 'object') {
    return {
      id: 0,
      name: '',
      phone: '',
      amount: 0,
      status: 'active',
      userId: 1,
    };
  }

  const cleanStringVal = (val: any): string | undefined => {
    if (val === null || val === undefined) return undefined;
    if (typeof val === 'object') {
      if (val.type === 'null') return undefined;
      if ('value' in val && val.value !== null && val.value !== undefined) {
        const v = String(val.value).trim();
        return v || undefined;
      }
      return undefined;
    }
    const str = String(val).trim();
    return str || undefined;
  };

  const cleanNumberVal = (val: any, fallback = 0): number => {
    if (val === null || val === undefined) return fallback;
    if (typeof val === 'object') {
      if (val.type === 'null') return fallback;
      if ('value' in val) {
        const n = Number(val.value);
        return isNaN(n) ? fallback : n;
      }
      return fallback;
    }
    const num = Number(val);
    return isNaN(num) ? fallback : num;
  };

  const cleanHistory = (raw: any): SupplierTransaction[] => {
    if (!raw) return [];
    let parsed = raw;
    if (typeof raw === 'object' && raw !== null) {
      if (raw.type === 'null') return [];
      if ('value' in raw) parsed = raw.value;
    }
    if (typeof parsed === 'string') {
      try { parsed = JSON.parse(parsed); } catch { return []; }
    }
    if (!Array.isArray(parsed)) return [];
    return parsed.map((tx: any) => ({
      id: String(tx?.id || Date.now().toString() + Math.random().toString(36).substring(2, 6)),
      supplierId: cleanNumberVal(tx?.supplierId, 0),
      type: tx?.type === 'pay_supplier' ? 'pay_supplier' : tx?.type === 'add_debt' ? 'add_debt' : 'initial',
      amount: cleanNumberVal(tx?.amount, 0),
      balanceAfter: cleanNumberVal(tx?.balanceAfter, 0),
      date: typeof tx?.date === 'string' ? tx.date : new Date().toISOString(),
      description: cleanStringVal(tx?.description),
      notes: cleanStringVal(tx?.notes),
      paymentMethod: tx?.paymentMethod || 'cash',
      invoiceImage: tx?.invoiceImage || undefined,
    }));
  };

  return {
    id: cleanNumberVal(s.id, 0),
    name: cleanStringVal(s.name) || 'مورد بدون اسم',
    phone: cleanStringVal(s.phone) || '',
    companyName: cleanStringVal(s.companyName),
    itemType: cleanStringVal(s.itemType),
    amount: cleanNumberVal(s.amount, 0),
    status: cleanStringVal(s.status) || 'active',
    userId: cleanNumberVal(s.userId, 1),
    createdAt: cleanStringVal(s.createdAt),
    history: cleanHistory(s.history),
    lastTransactionDate: cleanStringVal(s.lastTransactionDate),
    notes: cleanStringVal(s.notes),
    isDemo: Boolean(s.isDemo),
    invoiceImage: s.invoiceImage || undefined,
  };
}

export function getLocalSuppliers(userId: number): Supplier[] {
  try {
    const key = `suppliers_user_${userId}`;
    const saved = localStorage.getItem(key);
    if (!saved) return [];
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed.map(sanitizeSupplier) : [];
  } catch {
    return [];
  }
}

export function setLocalSuppliers(userId: number, suppliers: Supplier[]): void {
  try {
    const key = `suppliers_user_${userId}`;
    const safeSuppliers = Array.isArray(suppliers) ? suppliers.map(sanitizeSupplier) : [];
    localStorage.setItem(key, JSON.stringify(safeSuppliers));
  } catch (e) {
    console.warn("Could not set local suppliers:", e);
  }
}

export async function fetchSuppliersFromCloud(userId: number): Promise<Supplier[]> {
  try {
    let res;
    try {
      res = await queryTurso(
        `SELECT id, name, phone, company_name, item_type, amount, status, user_id, created_at, history, last_transaction_date, notes FROM suppliers WHERE user_id = ? ORDER BY id DESC;`,
        [userId]
      );
    } catch {
      await queryTurso(`CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        company_name TEXT,
        item_type TEXT,
        amount REAL DEFAULT 0,
        status TEXT DEFAULT 'active',
        user_id INTEGER DEFAULT 1,
        created_at TEXT,
        history TEXT,
        last_transaction_date TEXT,
        notes TEXT
      );`).catch(() => {});
      return getLocalSuppliers(userId);
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }

    const suppliers: Supplier[] = rows.map((r: any) => {
      return sanitizeSupplier({
        id: r[0],
        name: r[1],
        phone: r[2],
        companyName: r[3],
        itemType: r[4],
        amount: r[5],
        status: r[6],
        userId: r[7] ?? userId,
        createdAt: r[8],
        history: r[9],
        lastTransactionDate: r[10],
        notes: r[11],
      });
    });

    const localExisting = getLocalSuppliers(userId) || [];

    // Check for explicit deletes in deleted_records
    const deletedSupplierIds = new Set<string>();
    try {
      const delRes = await queryTurso(
        "SELECT id FROM deleted_records WHERE user_id = ? AND entity_type = 'supplier';",
        [userId]
      );
      if (delRes.results && delRes.results[0] && delRes.results[0].response?.result?.rows) {
        for (const r of delRes.results[0].response.result.rows) {
          if (r[0]?.value) deletedSupplierIds.add(String(r[0].value));
        }
      }
    } catch {}

    // Zero-Wipe Protection: إذا كانت السحابة فارغة ولكن الهاتف يحتوي على موردين غير محذوفين، نحافظ على بيانات الهاتف
    const nonDeletedLocal = localExisting.filter((s) => !deletedSupplierIds.has(String(s.id)));
    if (suppliers.length === 0 && nonDeletedLocal.length > 0 && deletedSupplierIds.size === 0) {
      return localExisting;
    }

    setLocalSuppliers(userId, suppliers);
    return suppliers;
  } catch (err) {
    console.warn("Could not fetch suppliers from cloud:", err);
    return getLocalSuppliers(userId);
  }
}

export async function syncSupplierToCloud(userId: number, supplier: Supplier): Promise<void> {
  try {
    if (supplier.isDemo || Number(supplier.id) < 0 || isTrialOrLocalUser(userId, supplier)) {
      return; // Never upload local demo or trial suppliers to cloud
    }
    const historyJson = JSON.stringify(supplier.history || []);
    await queryTurso(
      `INSERT INTO suppliers (id, name, phone, company_name, item_type, amount, status, user_id, created_at, history, last_transaction_date, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         name = excluded.name,
         phone = excluded.phone,
         company_name = excluded.company_name,
         item_type = excluded.item_type,
         amount = excluded.amount,
         status = excluded.status,
         history = excluded.history,
         last_transaction_date = excluded.last_transaction_date,
         notes = excluded.notes;`,
      [
        supplier.id,
        supplier.name,
        supplier.phone || '',
        supplier.companyName || null,
        supplier.itemType || null,
        supplier.amount,
        supplier.status || 'active',
        userId,
        supplier.createdAt || new Date().toISOString(),
        historyJson,
        supplier.lastTransactionDate || new Date().toISOString(),
        supplier.notes || null,
      ]
    );
  } catch (err) {
    console.warn("Could not sync supplier to cloud:", err);
  }
}

export async function deleteSupplierFromCloud(supplierId: number, userId?: number): Promise<void> {
  try {
    if (Number(supplierId) < 0 || (userId && isTrialOrLocalUser(userId))) return;
    const session = getLocalSession();
    if (session && isTrialOrLocalUser(session.id)) return;
    await queryTurso(`DELETE FROM suppliers WHERE id = ?;`, [supplierId]);
    const uId = userId || session?.id || 0;
    if (uId > 0) {
      await queryTurso(
        `INSERT OR REPLACE INTO deleted_records (id, entity_type, user_id, deleted_at) VALUES (?, 'supplier', ?, datetime('now'));`,
        [supplierId, uId]
      ).catch(() => {});
    }
  } catch (err) {
    console.warn("Could not delete supplier from cloud:", err);
  }
}

/**
 * فحص وحساب عدد الحسابات المسددة بالكامل (خالي من الدين / أقساط منتهية / موردين مسددين)
 * عبر جميع قواعد البيانات السحابية (الرئيسية، الثانوية، المنفصلة، والمضافة) والأنظمة، مخصصة للمستخدم الحالي
 */
export async function getSettledAccountsAcrossDatabases(threshold: number = 100, userId?: number): Promise<SettledStorageStats> {
  const customDbs = getLocalDatabases();

  const allTargets = [
    {
      id: 'primary_db',
      name: 'القاعدة الرئيسية (الافتراضية)',
      url: ALDION_DATABASE_CONFIG.url,
      token: ALDION_DATABASE_CONFIG.token,
    },
    ...BACKUP_SYNC_DATABASES.map((b, idx) => ({
      id: `backup_db_${idx + 1}`,
      name: b.name,
      url: b.url,
      token: b.token,
    })),
    ...BUILTIN_DEDICATED_DATABASES.map((b) => ({
      id: b.id,
      name: b.name,
      url: b.url,
      token: b.token,
    })),
    ...customDbs.map((c) => ({
      id: c.id,
      name: c.name,
      url: c.url,
      token: c.token,
    })),
  ];

  const extractVal = (res: any): number => {
    const val = res?.results?.[0]?.response?.result?.rows?.[0]?.[0];
    if (typeof val === 'object' && val !== null && 'value' in val) return Number(val.value);
    return Number(val || 0);
  };

  const breakdowns: {
    dbId: string;
    dbName: string;
    settledDebtors: number;
    settledInstallments: number;
    settledSuppliers: number;
    total: number;
  }[] = [];

  let primarySettledDebtors = 0;
  let primarySettledInstallments = 0;
  let primarySettledSuppliers = 0;

  const userWhere = userId ? " AND user_id = ?" : "";
  const userParams = userId ? [userId] : [];

  for (const target of allTargets) {
    try {
      const [dRes, iRes, sRes] = await Promise.all([
        queryCustomTursoDirect(
          target.url,
          target.token,
          `SELECT COUNT(*) FROM debtors WHERE (amount <= 0 OR status = 'خالي من الدين') AND id > 0${userWhere};`,
          userParams
        ).catch(() => null),
        queryCustomTursoDirect(
          target.url,
          target.token,
          `SELECT COUNT(*) FROM installments WHERE (remaining_amount <= 0 OR status = 'completed') AND id > 0${userWhere};`,
          userParams
        ).catch(() => null),
        queryCustomTursoDirect(
          target.url,
          target.token,
          `SELECT COUNT(*) FROM suppliers WHERE (remaining_amount <= 0 OR (total_amount > 0 AND paid_amount >= total_amount)) AND id > 0${userWhere};`,
          userParams
        ).catch(() => null),
      ]);

      const sDebtors = extractVal(dRes);
      const sInst = extractVal(iRes);
      const sSupp = extractVal(sRes);
      const subTotal = sDebtors + sInst + sSupp;

      if (target.id === 'primary_db') {
        primarySettledDebtors = sDebtors;
        primarySettledInstallments = sInst;
        primarySettledSuppliers = sSupp;
      }

      breakdowns.push({
        dbId: target.id,
        dbName: target.name,
        settledDebtors: sDebtors,
        settledInstallments: sInst,
        settledSuppliers: sSupp,
        total: subTotal,
      });
    } catch {
      // Ignore individual db error
    }
  }

  // إجمالي المسددين المعتمد في القاعدة الأساسية
  const effectiveTotal = primarySettledDebtors + primarySettledInstallments + primarySettledSuppliers;

  // إجمالي السجلات عبر جميع القواعد (مع أخذ الحد الأقصى بين القواعد للمطابقة)
  const maxDebtorsAcrossDbs = Math.max(primarySettledDebtors, ...breakdowns.map((b) => b.settledDebtors));
  const maxInstAcrossDbs = Math.max(primarySettledInstallments, ...breakdowns.map((b) => b.settledInstallments));
  const maxSuppAcrossDbs = Math.max(primarySettledSuppliers, ...breakdowns.map((b) => b.settledSuppliers));
  const crossDbTotal = maxDebtorsAcrossDbs + maxInstAcrossDbs + maxSuppAcrossDbs;

  const totalSettled = Math.max(effectiveTotal, crossDbTotal);

  const result: SettledStorageStats = {
    settledDebtors: maxDebtorsAcrossDbs,
    settledCreditors: 0,
    settledInstallments: maxInstAcrossDbs,
    settledSuppliers: maxSuppAcrossDbs,
    totalSettled,
    crossDbTotal,
    databasesCount: allTargets.length,
    isOverLimit: totalSettled >= threshold,
    limitThreshold: threshold,
    breakdownByDb: breakdowns,
  };

  try {
    const cacheKey = userId ? `aldion_settled_accounts_cache_${userId}` : 'aldion_settled_accounts_cache';
    localStorage.setItem(cacheKey, JSON.stringify({
      ...result,
      cachedAt: Date.now(),
    }));
  } catch {}

  return result;
}

/**
 * استرجاع إحصائيات الحسابات المسددة من الكاش المحلي فوراً دون انتظار شبكة (مخصص للمستخدم)
 */
export function getCachedSettledAccountsReport(threshold: number = 100, userId?: number): SettledStorageStats | null {
  try {
    const cacheKey = userId ? `aldion_settled_accounts_cache_${userId}` : 'aldion_settled_accounts_cache';
    const raw = localStorage.getItem(cacheKey);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...parsed,
        limitThreshold: threshold,
        isOverLimit: (parsed.totalSettled || 0) >= threshold,
      };
    }
  } catch {}
  return null;
}

/**
 * حذف جماعي لسجلات مدينين مسددين بالكامل من السحاب عبر جميع القواعد للمستخدم الحالي
 */
export async function batchDeleteSettledDebtorsFromCloud(debtorIds: number[], userId?: number): Promise<{
  ok: boolean;
  deletedCount: number;
  message: string;
}> {
  if (!debtorIds || debtorIds.length === 0) {
    return { ok: true, deletedCount: 0, message: 'لا توجد عناصر محددة للحذف' };
  }

  const validIds = debtorIds.filter((id) => Number(id) > 0);
  if (validIds.length === 0) {
    return { ok: true, deletedCount: 0, message: 'لا توجد معرفات صالحة' };
  }

  const customDbs = getLocalDatabases();
  const allTargets = [
    { id: 'primary_db', url: ALDION_DATABASE_CONFIG.url, token: ALDION_DATABASE_CONFIG.token },
    ...BACKUP_SYNC_DATABASES.map((b) => ({ id: b.name, url: b.url, token: b.token })),
    ...customDbs.map((c) => ({ id: c.id, url: c.url, token: c.token })),
  ];

  const placeholders = validIds.map(() => '?').join(',');
  const deleteSql = userId
    ? `DELETE FROM debtors WHERE id IN (${placeholders}) AND user_id = ?;`
    : `DELETE FROM debtors WHERE id IN (${placeholders});`;
  const deleteParams = userId ? [...validIds, userId] : validIds;

  let successCount = 0;
  for (const target of allTargets) {
    try {
      await queryCustomTursoDirect(target.url, target.token, deleteSql, deleteParams);
      successCount++;
    } catch (err) {
      console.warn(`Failed to batch delete from ${target.id}:`, err);
    }
  }

  // Record tombstones for multi-device sync
  if (userId) {
    for (const dId of validIds) {
      queryTurso(
        "INSERT OR REPLACE INTO deleted_records (id, entity_type, user_id, deleted_at) VALUES (?, 'debtor', ?, datetime('now'));",
        [dId, userId]
      ).catch(() => {});
    }
  }

  // تحديث الكاش المحلي فوراً
  try {
    const cached = getCachedSettledAccountsReport(100, userId);
    if (cached) {
      const newTotal = Math.max(0, cached.totalSettled - validIds.length);
      const newDebtors = Math.max(0, cached.settledDebtors - validIds.length);
      const cacheKey = userId ? `aldion_settled_accounts_cache_${userId}` : 'aldion_settled_accounts_cache';
      localStorage.setItem(cacheKey, JSON.stringify({
        ...cached,
        settledDebtors: newDebtors,
        totalSettled: newTotal,
        isOverLimit: newTotal >= (cached.limitThreshold || 100),
        cachedAt: Date.now(),
      }));
    }
  } catch {}

  return {
    ok: successCount > 0,
    deletedCount: validIds.length,
    message: `تم حذف ${validIds.length} حساب مسدد بالكامل بنجاح وتوفير مساحة التخزين عبر القواعد.`,
  };
}

/**
 * تنظيف تلقائي هادئ في الخلفية لسجلات الحذف المؤقتة التي مضى عليها أكثر من 30 يوماً
 * يحافظ على مساحة التخزين السحابي ويمنع تراكم أي بايتات غير ضرورية
 * يعمل بصمت تام في الخلفية مرة واحدة يومياً بدون أي أزرار أو تأثير على المستخدم
 */
export async function autoPurgeExpiredDeletedRecords(days: number = 30): Promise<void> {
  try {
    const lastPurgeKey = 'aldion_last_deleted_records_purge';
    const lastPurge = localStorage.getItem(lastPurgeKey);
    const now = Date.now();
    // فحص كل 24 ساعة فقط لمنع تكرار الاتصالات أو استهلاك موارد الشبكة
    if (lastPurge && now - Number(lastPurge) < 24 * 60 * 60 * 1000) {
      return;
    }

    const customDbs = getLocalDatabases();
    const allTargets = [
      { id: 'primary_db', url: ALDION_DATABASE_CONFIG.url, token: ALDION_DATABASE_CONFIG.token },
      ...BACKUP_SYNC_DATABASES.map((b) => ({ id: b.name, url: b.url, token: b.token })),
      ...customDbs.map((c) => ({ id: c.id, url: c.url, token: c.token })),
    ];

    const safeDays = Math.max(1, Number(days) || 30);
    const purgeSql = `DELETE FROM deleted_records WHERE deleted_at IS NOT NULL AND deleted_at < datetime('now', '-' || ? || ' days');`;

    for (const target of allTargets) {
      try {
        await queryCustomTursoDirect(target.url, target.token, purgeSql, [safeDays]);
      } catch (err) {
        // تجاهل أي خطأ بهدوء لضمان استقرار التطبيق
      }
    }

    localStorage.setItem(lastPurgeKey, String(now));
  } catch (err) {
    // تشغيل هادئ بدون أي تأثير على عمل التطبيق
  }
}


